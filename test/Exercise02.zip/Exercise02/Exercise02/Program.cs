﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise02
{
    class Program
    {
        static void Main(string[] args)
        {
            int counter = 1;
            string[] names = new string[] {"Viktor", "Petar", "Dario"};
            
            Console.WriteLine("Enter your name: ");
            string input = Console.ReadLine();
            int index = names.Length;
            names[index + 1] = input;
            
            //foreach (string name in names)
            //{
            //Console.WriteLine(name); 
            //}
            for (int i = 0; i < names.Length; i++)
            {
                Console.WriteLine(names[i]);
                
            }
            Array.Resize(ref names, counter);

            Console.ReadLine();
        }
    }
}
